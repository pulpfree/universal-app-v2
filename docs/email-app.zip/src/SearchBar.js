import React from 'react';

const SearchBar = () => (
  <div>
    <input placeholder="Search your mail" />
  </div>
);

export default SearchBar;
