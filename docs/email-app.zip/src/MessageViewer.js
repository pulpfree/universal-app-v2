import React from 'react';

const MessageViewer = () => (
  <div className="MessageViewer">Select a message</div>
);

export default MessageViewer;
